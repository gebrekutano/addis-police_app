const Role = require('../models/role');

const createRole = async (req, res) => {
  try {
    // Extract role data from request body
    const { name, permissions } = req.body;

    // Create a new role instance
    const newRole = new Role({ name, permissions });

    // Save the new role to the database
    const role = await newRole.save();

    res.status(201).json(role);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

module.exports = { createRole };
