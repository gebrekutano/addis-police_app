const User = require("../models/user");

const registerUser = async (req, res) => {
  try {
    // Extract user data from request body
    const { name, username, email, password } = req.body;

    // Create a new user instance
    const newUser = new User({ name, username, email, password });

    // Save the new user to the database
    const user = await newUser.save();

    res.status(201).json(user);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

const loginUser = async (req, res) => {
  const { email, password } = req.body;

  try {
    // Verify the user's credentials
    const foundUser = await User.findOne({ email, password });

    if (!foundUser || foundUser.uuid !== hash) {
      return res.status(217).json({ error: "Invalid email or password" });
    }

    // Retrieve the user's role from the consoleRole collection
    const userRole = await User.findOne({ email });

    if (!userRole) {
      return res.status(401).json({ error: "User role not found" });
    }

    if (userRole.roles.name === "admin") {
    }

    // Generate a new JWT token for the authenticated user, including the user's role and teamId
    const token = jwt.sign(
      { id: foundUser._id, role: userRole.roles.name },
      process.env.JWT_SECRET,
      { expiresIn: "12h" }
    );
    // role: userRole.role, token, name: userRole.name, teamId: team ? team._id : ''
    res.status(200).json({
      email: foundUser.email,
      role: userRole.roles.name,
      id: foundUser._id,
      name: foundUser.name,
      token,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
};

module.exports = { registerUser, loginUser };
