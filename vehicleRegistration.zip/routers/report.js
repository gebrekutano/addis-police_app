const express = require("express");
const router = express.Router();
const WantedReport = require("../controllers/WantedReport");

router.get("/Reports/:filter", WantedReport.getCounts);

module.exports = router;
